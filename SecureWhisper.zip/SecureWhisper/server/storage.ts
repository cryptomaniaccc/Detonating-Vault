import { 
  users, User, InsertUser, 
  files, File, InsertFile,
  notes, Note, InsertNote
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserVoicePattern(id: number, voicePattern: string): Promise<User>;
  updateUserPasscode(id: number, passcode: string): Promise<User>;
  incrementFailedAttempts(id: number): Promise<number>;
  resetFailedAttempts(id: number): Promise<void>;
  
  // File operations
  getFiles(userId: number): Promise<File[]>;
  getFile(id: number): Promise<File | undefined>;
  createFile(userId: number, file: InsertFile): Promise<File>;
  deleteFile(id: number): Promise<void>;
  
  // Note operations
  getNotes(userId: number): Promise<Note[]>;
  getNote(id: number): Promise<Note | undefined>;
  createNote(userId: number, note: InsertNote): Promise<Note>;
  deleteNote(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private files: Map<number, File>;
  private notes: Map<number, Note>;
  private userIdCounter: number;
  private fileIdCounter: number;
  private noteIdCounter: number;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.notes = new Map();
    this.userIdCounter = 1;
    this.fileIdCounter = 1;
    this.noteIdCounter = 1;
    
    // Add demo user
    this.createUser({
      username: "mayank",
      password: "password123",
      passcode: "1234",
      voicePattern: ""
    });
    
    // Add some demo files for the user
    this.createFile(1, {
      name: "Tax_Returns_2023.pdf",
      content: "This is a tax returns document",
      type: "pdf",
      encrypted: true
    });
    
    this.createFile(1, {
      name: "Passwords.kdbx",
      content: "This is a password file",
      type: "key",
      encrypted: true
    });
    
    this.createFile(1, {
      name: "ID_Documents",
      content: "This contains ID documents",
      type: "image",
      encrypted: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      failedAttempts: 0
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserVoicePattern(id: number, voicePattern: string): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    user.voicePattern = voicePattern;
    this.users.set(id, user);
    return user;
  }
  
  async updateUserPasscode(id: number, passcode: string): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    user.passcode = passcode;
    this.users.set(id, user);
    return user;
  }
  
  async incrementFailedAttempts(id: number): Promise<number> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    user.failedAttempts += 1;
    this.users.set(id, user);
    return user.failedAttempts;
  }
  
  async resetFailedAttempts(id: number): Promise<void> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    user.failedAttempts = 0;
    this.users.set(id, user);
  }

  // File operations
  async getFiles(userId: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.userId === userId
    );
  }
  
  async getFile(id: number): Promise<File | undefined> {
    return this.files.get(id);
  }
  
  async createFile(userId: number, insertFile: InsertFile): Promise<File> {
    const id = this.fileIdCounter++;
    const now = new Date();
    const file: File = {
      ...insertFile,
      id,
      userId,
      createdAt: now
    };
    this.files.set(id, file);
    return file;
  }
  
  async deleteFile(id: number): Promise<void> {
    this.files.delete(id);
  }
  
  // Note operations
  async getNotes(userId: number): Promise<Note[]> {
    return Array.from(this.notes.values()).filter(
      (note) => note.userId === userId
    );
  }
  
  async getNote(id: number): Promise<Note | undefined> {
    return this.notes.get(id);
  }
  
  async createNote(userId: number, insertNote: InsertNote): Promise<Note> {
    const id = this.noteIdCounter++;
    const now = new Date();
    const note: Note = {
      ...insertNote,
      id,
      userId,
      createdAt: now
    };
    this.notes.set(id, note);
    return note;
  }
  
  async deleteNote(id: number): Promise<void> {
    this.notes.delete(id);
  }
}

export const storage = new MemStorage();
