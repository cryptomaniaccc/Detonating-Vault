import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, passcodeSchema, voiceAuthSchema, 
  insertFileSchema, insertNoteSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(validatedData.username);
      
      if (!user || user.password !== validatedData.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = user;
      
      return res.json({ user: userWithoutPassword });
    } catch (error) {
      return res.status(400).json({ message: "Invalid request", error });
    }
  });
  
  app.post("/api/auth/voice", async (req, res) => {
    try {
      const validatedData = voiceAuthSchema.parse(req.body);
      const user = await storage.getUserByUsername(validatedData.username);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // If no voice pattern is set yet, just save this one
      if (!user.voicePattern) {
        await storage.updateUserVoicePattern(user.id, validatedData.voicePattern);
        return res.json({ success: true, isNewPattern: true });
      }
      
      // Simple voice pattern comparison - in a real app, this would be more sophisticated
      const isMatch = user.voicePattern === validatedData.voicePattern;
      
      if (!isMatch) {
        const attempts = await storage.incrementFailedAttempts(user.id);
        return res.status(401).json({ 
          success: false, 
          message: "Voice pattern does not match", 
          attempts,
          maxAttempts: 5 
        });
      }
      
      // Reset failed attempts on success
      await storage.resetFailedAttempts(user.id);
      
      return res.json({ success: true });
    } catch (error) {
      return res.status(400).json({ message: "Invalid request", error });
    }
  });
  
  app.post("/api/auth/passcode", async (req, res) => {
    try {
      const validatedData = passcodeSchema.parse(req.body);
      const userId = req.body.userId; // Should come from session in real app
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      const isMatch = user.passcode === validatedData.passcode;
      
      if (!isMatch) {
        const attempts = await storage.incrementFailedAttempts(user.id);
        return res.status(401).json({ 
          success: false, 
          message: "Passcode does not match", 
          attempts,
          maxAttempts: 5 
        });
      }
      
      // Reset failed attempts on success
      await storage.resetFailedAttempts(user.id);
      
      return res.json({ success: true });
    } catch (error) {
      return res.status(400).json({ message: "Invalid request", error });
    }
  });
  
  // File routes
  app.get("/api/files", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string); // Should come from session in real app
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      const files = await storage.getFiles(userId);
      return res.json(files);
    } catch (error) {
      return res.status(500).json({ message: "Server error", error });
    }
  });
  
  app.post("/api/files", async (req, res) => {
    try {
      const validatedData = insertFileSchema.parse(req.body.file);
      const userId = parseInt(req.body.userId); // Should come from session in real app
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      const file = await storage.createFile(userId, validatedData);
      return res.status(201).json(file);
    } catch (error) {
      return res.status(400).json({ message: "Invalid request", error });
    }
  });
  
  app.delete("/api/files/:id", async (req, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      await storage.deleteFile(fileId);
      return res.json({ success: true });
    } catch (error) {
      return res.status(500).json({ message: "Server error", error });
    }
  });
  
  // Note routes
  app.get("/api/notes", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string); // Should come from session in real app
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      const notes = await storage.getNotes(userId);
      return res.json(notes);
    } catch (error) {
      return res.status(500).json({ message: "Server error", error });
    }
  });
  
  app.post("/api/notes", async (req, res) => {
    try {
      const validatedData = insertNoteSchema.parse(req.body.note);
      const userId = parseInt(req.body.userId); // Should come from session in real app
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      const note = await storage.createNote(userId, validatedData);
      return res.status(201).json(note);
    } catch (error) {
      return res.status(400).json({ message: "Invalid request", error });
    }
  });
  
  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      const note = await storage.getNote(noteId);
      
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      await storage.deleteNote(noteId);
      return res.json({ success: true });
    } catch (error) {
      return res.status(500).json({ message: "Server error", error });
    }
  });
  
  // Self-destruct route
  app.post("/api/self-destruct", async (req, res) => {
    try {
      const userId = parseInt(req.body.userId);
      
      if (!userId) {
        return res.status(401).json({ message: "User ID required" });
      }
      
      // Get all files for this user
      const userFiles = await storage.getFiles(userId);
      
      // Delete all files
      for (const file of userFiles) {
        await storage.deleteFile(file.id);
      }
      
      // Get all notes for this user
      const userNotes = await storage.getNotes(userId);
      
      // Delete all notes
      for (const note of userNotes) {
        await storage.deleteNote(note.id);
      }
      
      return res.json({ success: true, deletedFilesCount: userFiles.length, deletedNotesCount: userNotes.length });
    } catch (error) {
      return res.status(500).json({ message: "Server error", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
