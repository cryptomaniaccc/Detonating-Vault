import { User, File, Note } from "@shared/schema";

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  failedAttempts: number;
  isListening: boolean;
  isProcessing: boolean;
  isSuccess: boolean;
  isFailed: boolean;
  isDestroying: boolean;
}

export interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<boolean>;
  authenticateVoice: (username: string, voicePattern: string) => Promise<boolean>;
  authenticatePasscode: (userId: number, passcode: string) => Promise<boolean>;
  startVoiceAuth: () => void;
  stopVoiceAuth: () => void;
  logout: () => void;
  resetAuth: () => void;
  selfDestruct: (userId: number) => Promise<void>;
}

export interface VaultItem {
  id: number;
  name: string;
  type: string;
  createdAt: Date;
}

export interface VaultState {
  files: File[];
  notes: Note[];
  activeSection: 'files' | 'notes' | 'settings';
  isLoading: boolean;
}

export interface VaultContextType extends VaultState {
  fetchFiles: (userId: number) => Promise<void>;
  fetchNotes: (userId: number) => Promise<void>;
  addFile: (userId: number, file: Omit<File, 'id' | 'userId' | 'createdAt'>) => Promise<void>;
  addNote: (userId: number, note: Omit<Note, 'id' | 'userId' | 'createdAt'>) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  deleteNote: (id: number) => Promise<void>;
  setActiveSection: (section: 'files' | 'notes' | 'settings') => void;
}

export interface DestructionState {
  isActive: boolean;
  progress: number;
  fileCounter: { current: number; total: number };
  shredProgress: number;
  overwriteCounter: { current: number; total: number };
}
