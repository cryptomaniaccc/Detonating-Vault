import { type ClassValue, clsx } from "clsx";
import { format } from "date-fns";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  return format(date, "MM/dd/yyyy");
}

// Simple encryption/decryption functions (for demo purposes only)
export function encrypt(text: string): string {
  // In a real app, use a proper encryption library
  return btoa(text);
}

export function decrypt(text: string): string {
  // In a real app, use a proper decryption library
  return atob(text);
}

// Convert audio data to string for storage
export function audioToString(audioData: Float32Array): string {
  return Array.from(audioData).join(',');
}

// Convert string back to audio data
export function stringToAudio(audioString: string): Float32Array {
  return new Float32Array(audioString.split(',').map(Number));
}

// Calculate similarity between two audio patterns
export function calculateSimilarity(pattern1: string, pattern2: string): number {
  // In a real app, use a proper audio pattern matching algorithm
  // This is just a simple example
  const array1 = pattern1.split(',').map(Number);
  const array2 = pattern2.split(',').map(Number);
  
  // Simple correlation coefficient
  let sum1 = 0, sum2 = 0, sum1Sq = 0, sum2Sq = 0, pSum = 0;
  const n = Math.min(array1.length, array2.length);
  
  for (let i = 0; i < n; i++) {
    sum1 += array1[i];
    sum2 += array2[i];
    sum1Sq += array1[i] ** 2;
    sum2Sq += array2[i] ** 2;
    pSum += array1[i] * array2[i];
  }
  
  const num = pSum - (sum1 * sum2 / n);
  const den = Math.sqrt((sum1Sq - sum1 ** 2 / n) * (sum2Sq - sum2 ** 2 / n));
  
  return num / den;
}

// Generate file icon based on type
export function getFileIcon(type: string): string {
  switch (type.toLowerCase()) {
    case 'pdf':
      return 'file-pdf';
    case 'key':
    case 'password':
      return 'key';
    case 'image':
      return 'image';
    case 'doc':
    case 'docx':
      return 'file-text';
    case 'xls':
    case 'xlsx':
      return 'file-spreadsheet';
    default:
      return 'file';
  }
}
