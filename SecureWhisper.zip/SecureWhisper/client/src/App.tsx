import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./context/AuthContext";
import { VaultProvider } from "./context/VaultContext";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";

// Main App component with all providers properly nested
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <VaultProvider>
          <div className="app">
            <Switch>
              <Route path="/" component={Home} />
              <Route component={NotFound} />
            </Switch>
            <Toaster />
          </div>
        </VaultProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
