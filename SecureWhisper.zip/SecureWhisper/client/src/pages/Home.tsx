import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import AuthenticationScreen from '@/components/AuthenticationScreen';
import VaultScreen from '@/components/VaultScreen';
import DestructionScreen from '@/components/DestructionScreen';

const Home: React.FC = () => {
  const { isAuthenticated, isDestroying, logout } = useAuth();
  const [showVault, setShowVault] = useState(false);
  
  // Handle successful authentication
  const handleAuthSuccess = () => {
    setTimeout(() => {
      setShowVault(true);
    }, 1500);
  };
  
  // Handle destruction completion
  const handleDestructionComplete = () => {
    logout();
  };
  
  useEffect(() => {
    if (!isAuthenticated) {
      setShowVault(false);
    }
  }, [isAuthenticated]);
  
  return (
    <div className="container mx-auto px-4 py-8 flex flex-col items-center justify-center min-h-screen relative">
      {!showVault && !isDestroying && (
        <AuthenticationScreen onSuccess={handleAuthSuccess} />
      )}
      
      {showVault && !isDestroying && (
        <VaultScreen />
      )}
      
      <DestructionScreen 
        isActive={isDestroying} 
        onComplete={handleDestructionComplete} 
      />
    </div>
  );
};

export default Home;
