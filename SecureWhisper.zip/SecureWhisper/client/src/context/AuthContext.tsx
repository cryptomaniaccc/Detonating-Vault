import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from '@/lib/queryClient';
import { User } from '@shared/schema';
import { AuthState, AuthContextType } from '@/lib/types';

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  failedAttempts: 0,
  isListening: false,
  isProcessing: false,
  isSuccess: false,
  isFailed: false,
  isDestroying: false
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(initialState);
  const { toast } = useToast();

  const login = async (username: string, password: string): Promise<boolean> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const response = await apiRequest('POST', '/api/auth/login', { username, password });
      const data = await response.json();
      
      setState(prev => ({ 
        ...prev, 
        user: data.user, 
        isLoading: false 
      }));
      
      return true;
    } catch (error) {
      console.error('Login error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Login Failed",
        description: "Invalid username or password",
        variant: "destructive",
      });
      return false;
    }
  };

  const authenticateVoice = async (username: string, voicePattern: string): Promise<boolean> => {
    setState(prev => ({ ...prev, isProcessing: true }));
    
    try {
      const response = await apiRequest('POST', '/api/auth/voice', { 
        username, 
        voicePattern 
      });
      const data = await response.json();
      
      if (data.success) {
        setState(prev => ({ 
          ...prev, 
          isProcessing: false,
          isSuccess: true,
          isAuthenticated: true,
          isFailed: false,
          failedAttempts: 0
        }));
        
        setTimeout(() => {
          setState(prev => ({ ...prev, isSuccess: false }));
        }, 1500);
        
        return true;
      }
      
      return false;
    } catch (error: any) {
      console.error('Voice auth error:', error);
      
      // Check if we got a 401 with attempts info
      if (error.message?.includes('401')) {
        try {
          const errorData = JSON.parse(error.message.split(': ')[1]);
          setState(prev => ({ 
            ...prev, 
            isProcessing: false,
            isFailed: true,
            failedAttempts: errorData.attempts || (prev.failedAttempts + 1)
          }));
          
          // Handle destruction if max attempts reached
          if (errorData.attempts >= 5) {
            setState(prev => ({ ...prev, isDestroying: true }));
            if (state.user) {
              await selfDestruct(state.user.id);
            }
          }
        } catch {
          setState(prev => ({ 
            ...prev, 
            isProcessing: false,
            isFailed: true,
            failedAttempts: prev.failedAttempts + 1
          }));
        }
      } else {
        setState(prev => ({ 
          ...prev, 
          isProcessing: false,
          isFailed: true,
          failedAttempts: prev.failedAttempts + 1
        }));
      }
      
      toast({
        title: "Authentication Failed",
        description: "Voice pattern does not match",
        variant: "destructive",
      });
      
      setTimeout(() => {
        setState(prev => ({ ...prev, isFailed: false }));
      }, 2000);
      
      return false;
    }
  };

  const authenticatePasscode = async (userId: number, passcode: string): Promise<boolean> => {
    setState(prev => ({ ...prev, isProcessing: true }));
    
    try {
      const response = await apiRequest('POST', '/api/auth/passcode', { 
        userId, 
        passcode 
      });
      const data = await response.json();
      
      if (data.success) {
        setState(prev => ({ 
          ...prev, 
          isProcessing: false,
          isSuccess: true,
          isAuthenticated: true,
          isFailed: false,
          failedAttempts: 0
        }));
        
        setTimeout(() => {
          setState(prev => ({ ...prev, isSuccess: false }));
        }, 1500);
        
        return true;
      }
      
      return false;
    } catch (error: any) {
      console.error('Passcode auth error:', error);
      
      // Check if we got a 401 with attempts info
      if (error.message?.includes('401')) {
        try {
          const errorData = JSON.parse(error.message.split(': ')[1]);
          setState(prev => ({ 
            ...prev, 
            isProcessing: false,
            isFailed: true,
            failedAttempts: errorData.attempts || (prev.failedAttempts + 1)
          }));
          
          // Handle destruction if max attempts reached
          if (errorData.attempts >= 5) {
            setState(prev => ({ ...prev, isDestroying: true }));
            if (state.user) {
              await selfDestruct(state.user.id);
            }
          }
        } catch {
          setState(prev => ({ 
            ...prev, 
            isProcessing: false,
            isFailed: true,
            failedAttempts: prev.failedAttempts + 1
          }));
        }
      } else {
        setState(prev => ({ 
          ...prev, 
          isProcessing: false,
          isFailed: true,
          failedAttempts: prev.failedAttempts + 1
        }));
      }
      
      toast({
        title: "Authentication Failed",
        description: "Passcode does not match",
        variant: "destructive",
      });
      
      setTimeout(() => {
        setState(prev => ({ ...prev, isFailed: false }));
      }, 2000);
      
      return false;
    }
  };
  
  const startVoiceAuth = () => {
    setState(prev => ({ ...prev, isListening: true }));
  };
  
  const stopVoiceAuth = () => {
    setState(prev => ({ ...prev, isListening: false }));
  };
  
  const logout = () => {
    setState(initialState);
  };
  
  const resetAuth = () => {
    setState(prev => ({
      ...prev,
      isListening: false,
      isProcessing: false,
      isSuccess: false,
      isFailed: false
    }));
  };
  
  const selfDestruct = async (userId: number): Promise<void> => {
    setState(prev => ({ ...prev, isDestroying: true }));
    
    try {
      await apiRequest('POST', '/api/self-destruct', { userId });
      // We don't reset the state here because we want to show the destruction animation
    } catch (error) {
      console.error('Self-destruct error:', error);
      toast({
        title: "Error",
        description: "Failed to self-destruct data",
        variant: "destructive",
      });
    }
  };
  
  const value = {
    ...state,
    login,
    authenticateVoice,
    authenticatePasscode,
    startVoiceAuth,
    stopVoiceAuth,
    logout,
    resetAuth,
    selfDestruct
  };
  
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
