import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from '@/lib/queryClient';
import { File, Note } from '@shared/schema';
import { VaultState, VaultContextType } from '@/lib/types';

const initialState: VaultState = {
  files: [],
  notes: [],
  activeSection: 'files',
  isLoading: false
};

const VaultContext = createContext<VaultContextType | undefined>(undefined);

export function VaultProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<VaultState>(initialState);
  const { toast } = useToast();

  const fetchFiles = async (userId: number): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const response = await apiRequest('GET', `/api/files?userId=${userId}`, undefined);
      const files = await response.json();
      
      setState(prev => ({ 
        ...prev, 
        files, 
        isLoading: false 
      }));
    } catch (error) {
      console.error('Fetch files error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to fetch files",
        variant: "destructive",
      });
    }
  };

  const fetchNotes = async (userId: number): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const response = await apiRequest('GET', `/api/notes?userId=${userId}`, undefined);
      const notes = await response.json();
      
      setState(prev => ({ 
        ...prev, 
        notes, 
        isLoading: false 
      }));
    } catch (error) {
      console.error('Fetch notes error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to fetch notes",
        variant: "destructive",
      });
    }
  };

  const addFile = async (userId: number, file: Omit<File, 'id' | 'userId' | 'createdAt'>): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const response = await apiRequest('POST', '/api/files', { 
        userId, 
        file 
      });
      const newFile = await response.json();
      
      setState(prev => ({ 
        ...prev, 
        files: [...prev.files, newFile], 
        isLoading: false 
      }));
      
      toast({
        title: "Success",
        description: "File added successfully",
      });
    } catch (error) {
      console.error('Add file error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to add file",
        variant: "destructive",
      });
    }
  };

  const addNote = async (userId: number, note: Omit<Note, 'id' | 'userId' | 'createdAt'>): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const response = await apiRequest('POST', '/api/notes', { 
        userId, 
        note 
      });
      const newNote = await response.json();
      
      setState(prev => ({ 
        ...prev, 
        notes: [...prev.notes, newNote], 
        isLoading: false 
      }));
      
      toast({
        title: "Success",
        description: "Note added successfully",
      });
    } catch (error) {
      console.error('Add note error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to add note",
        variant: "destructive",
      });
    }
  };

  const deleteFile = async (id: number): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      await apiRequest('DELETE', `/api/files/${id}`, undefined);
      
      setState(prev => ({ 
        ...prev, 
        files: prev.files.filter(file => file.id !== id), 
        isLoading: false 
      }));
      
      toast({
        title: "Success",
        description: "File deleted successfully",
      });
    } catch (error) {
      console.error('Delete file error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to delete file",
        variant: "destructive",
      });
    }
  };

  const deleteNote = async (id: number): Promise<void> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      await apiRequest('DELETE', `/api/notes/${id}`, undefined);
      
      setState(prev => ({ 
        ...prev, 
        notes: prev.notes.filter(note => note.id !== id), 
        isLoading: false 
      }));
      
      toast({
        title: "Success",
        description: "Note deleted successfully",
      });
    } catch (error) {
      console.error('Delete note error:', error);
      setState(prev => ({ ...prev, isLoading: false }));
      toast({
        title: "Error",
        description: "Failed to delete note",
        variant: "destructive",
      });
    }
  };

  const setActiveSection = (section: 'files' | 'notes' | 'settings'): void => {
    setState(prev => ({ ...prev, activeSection: section }));
  };
  
  const value = {
    ...state,
    fetchFiles,
    fetchNotes,
    addFile,
    addNote,
    deleteFile,
    deleteNote,
    setActiveSection
  };
  
  return <VaultContext.Provider value={value}>{children}</VaultContext.Provider>;
}

export function useVault(): VaultContextType {
  const context = useContext(VaultContext);
  if (context === undefined) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
}
