import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DestructionState } from '@/lib/types';

interface DestructionScreenProps {
  isActive: boolean;
  onComplete?: () => void;
}

const DestructionScreen: React.FC<DestructionScreenProps> = ({ 
  isActive,
  onComplete
}) => {
  const [state, setState] = useState<DestructionState>({
    isActive: false,
    progress: 0,
    fileCounter: { current: 0, total: 37 },
    shredProgress: 0,
    overwriteCounter: { current: 0, total: 3 }
  });
  
  useEffect(() => {
    if (isActive && !state.isActive) {
      setState(prev => ({ ...prev, isActive: true }));
      
      // Start file deletion counter
      const fileInterval = setInterval(() => {
        setState(prev => {
          const newCurrent = prev.fileCounter.current + 1;
          return {
            ...prev,
            fileCounter: {
              ...prev.fileCounter,
              current: Math.min(newCurrent, prev.fileCounter.total)
            }
          };
        });
      }, 100);
      
      // Start shredding progress
      const shredInterval = setInterval(() => {
        setState(prev => ({
          ...prev,
          shredProgress: Math.min(prev.shredProgress + 2, 100)
        }));
      }, 150);
      
      // Start overwrite counter after a delay
      setTimeout(() => {
        const overwriteInterval = setInterval(() => {
          setState(prev => {
            const newCurrent = prev.overwriteCounter.current + 1;
            return {
              ...prev,
              overwriteCounter: {
                ...prev.overwriteCounter,
                current: Math.min(newCurrent, prev.overwriteCounter.total)
              }
            };
          });
          
          // If we're done with all processes, clear all intervals
          setState(prev => {
            const isComplete = 
              prev.fileCounter.current >= prev.fileCounter.total &&
              prev.shredProgress >= 100 &&
              prev.overwriteCounter.current >= prev.overwriteCounter.total;
              
            if (isComplete && onComplete) {
              // Clear all intervals and call onComplete after a delay
              clearInterval(fileInterval);
              clearInterval(shredInterval);
              clearInterval(overwriteInterval);
              
              setTimeout(() => {
                onComplete();
              }, 2000);
            }
            
            return prev;
          });
        }, 1000);
        
        // Clean up
        return () => {
          clearInterval(fileInterval);
          clearInterval(shredInterval);
          clearInterval(overwriteInterval);
        };
      }, 2000);
    }
  }, [isActive, state.isActive, onComplete]);
  
  // Calculate overall progress
  useEffect(() => {
    const fileProgress = state.fileCounter.current / state.fileCounter.total * 0.5;
    const shredProgress = state.shredProgress / 100 * 0.3;
    const overwriteProgress = state.overwriteCounter.current / state.overwriteCounter.total * 0.2;
    
    const totalProgress = fileProgress + shredProgress + overwriteProgress;
    setState(prev => ({ ...prev, progress: totalProgress }));
  }, [state.fileCounter, state.shredProgress, state.overwriteCounter]);
  
  return (
    <motion.div 
      className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center text-center"
      initial={{ scale: 0 }}
      animate={{ scale: isActive ? 1 : 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    >
      <div className="glitch-container">
        <h1 className="font-['Audiowide'] text-red-500 text-7xl mb-4">SECURITY BREACH</h1>
        <div className="relative w-full h-1 bg-red-500/20 mb-8">
          <motion.div 
            className="absolute h-full bg-red-500"
            animate={{ width: `${state.progress * 100}%` }}
            transition={{ type: "spring", stiffness: 100 }}
          />
        </div>
        <p className="font-mono text-xl mb-2">UNAUTHORIZED ACCESS DETECTED</p>
        <p className="font-mono text-xl mb-8">INITIATING DESTRUCTION SEQUENCE</p>
        
        <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto mb-8">
          <div className="bg-primary/50 border border-red-500/50 rounded p-4">
            <p className="font-mono text-sm">DELETING</p>
            <p className="text-red-500 font-mono">
              {state.fileCounter.current}/{state.fileCounter.total}
            </p>
          </div>
          <div className="bg-primary/50 border border-red-500/50 rounded p-4">
            <p className="font-mono text-sm">SHREDDING</p>
            <p className="text-red-500 font-mono">{state.shredProgress}%</p>
          </div>
          <div className="bg-primary/50 border border-red-500/50 rounded p-4">
            <p className="font-mono text-sm">OVERWRITE</p>
            <p className="text-red-500 font-mono">
              {state.overwriteCounter.current}/{state.overwriteCounter.total}
            </p>
          </div>
        </div>
        
        <div className="flex justify-center items-center">
          <motion.div
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-6xl text-red-500"
          >
            ⚠️
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default DestructionScreen;
