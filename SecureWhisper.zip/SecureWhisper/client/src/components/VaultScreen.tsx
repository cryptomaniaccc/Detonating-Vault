import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/context/AuthContext';
import { useVault } from '@/context/VaultContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { formatDate, getFileIcon } from '@/lib/utils';

interface VaultScreenProps {}

const VaultScreen: React.FC<VaultScreenProps> = () => {
  const { user, logout } = useAuth();
  const { 
    files, 
    notes, 
    activeSection, 
    isLoading,
    fetchFiles,
    fetchNotes,
    addFile,
    addNote,
    deleteFile,
    deleteNote,
    setActiveSection
  } = useVault();
  
  const [newFile, setNewFile] = useState({ name: '', content: '', type: 'pdf' });
  const [newNote, setNewNote] = useState({ title: '', content: '' });
  const [isAddFileOpen, setIsAddFileOpen] = useState(false);
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  
  // Fetch data when user is authenticated
  useEffect(() => {
    if (user) {
      fetchFiles(user.id);
      fetchNotes(user.id);
    }
  }, [user, fetchFiles, fetchNotes]);
  
  const handleAddFile = () => {
    if (user && newFile.name && newFile.content) {
      addFile(user.id, {
        name: newFile.name,
        content: newFile.content,
        type: newFile.type,
        encrypted: true
      });
      setNewFile({ name: '', content: '', type: 'pdf' });
      setIsAddFileOpen(false);
    }
  };
  
  const handleAddNote = () => {
    if (user && newNote.title && newNote.content) {
      addNote(user.id, {
        title: newNote.title,
        content: newNote.content
      });
      setNewNote({ title: '', content: '' });
      setIsAddNoteOpen(false);
    }
  };
  
  return (
    <div className="w-full max-w-4xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="font-['Audiowide'] text-3xl text-cyan-500">SECURE VAULT</h2>
          <p className="font-mono text-sm text-neutral/60">Voice authenticated: Security Level Alpha</p>
        </div>
        <Button
          onClick={logout}
          variant="outline"
          className="bg-primary hover:bg-primary/80 text-neutral font-mono py-2 px-4 rounded-lg border border-cyan-500/30 flex items-center"
        >
          <span className="text-red-500 mr-2">⏻</span>
          LOGOUT
        </Button>
      </div>
      
      {/* Vault Navigation */}
      <div className="bg-primary rounded-lg border border-cyan-500/30 p-1 flex mb-8">
        <button 
          onClick={() => setActiveSection('files')}
          className={`flex-1 py-3 font-mono text-sm rounded ${
            activeSection === 'files' ? 'bg-background/20 text-cyan-500' : ''
          }`}
        >
          FILES
        </button>
        <button 
          onClick={() => setActiveSection('notes')}
          className={`flex-1 py-3 font-mono text-sm rounded ${
            activeSection === 'notes' ? 'bg-background/20 text-cyan-500' : ''
          }`}
        >
          NOTES
        </button>
        <button 
          onClick={() => setActiveSection('settings')}
          className={`flex-1 py-3 font-mono text-sm rounded ${
            activeSection === 'settings' ? 'bg-background/20 text-cyan-500' : ''
          }`}
        >
          SETTINGS
        </button>
      </div>
      
      {/* Files Section */}
      {activeSection === 'files' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-primary/50 rounded-lg border border-cyan-500/30 p-6"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-mono text-lg">Secured Files</h3>
            <Dialog open={isAddFileOpen} onOpenChange={setIsAddFileOpen}>
              <DialogTrigger asChild>
                <Button className="bg-cyan-500 hover:bg-cyan-500/80 text-background font-mono py-2 px-4 rounded flex items-center text-sm">
                  <span className="mr-2">+</span>
                  ADD NEW
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New File</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="fileName" className="text-sm">File Name</label>
                    <Input 
                      id="fileName"
                      value={newFile.name}
                      onChange={(e) => setNewFile({...newFile, name: e.target.value})}
                      placeholder="Enter file name"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="fileType" className="text-sm">File Type</label>
                    <select 
                      id="fileType"
                      value={newFile.type}
                      onChange={(e) => setNewFile({...newFile, type: e.target.value})}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="pdf">PDF</option>
                      <option value="key">Password/Key</option>
                      <option value="image">Image</option>
                      <option value="doc">Document</option>
                    </select>
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="fileContent" className="text-sm">Content</label>
                    <Textarea 
                      id="fileContent"
                      value={newFile.content}
                      onChange={(e) => setNewFile({...newFile, content: e.target.value})}
                      placeholder="Enter file content"
                      rows={4}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    onClick={handleAddFile}
                    className="bg-cyan-500 hover:bg-cyan-500/80"
                  >
                    Add File
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {/* File Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.length === 0 && !isLoading ? (
              <p className="col-span-3 text-center text-gray-400 py-8">No files added yet.</p>
            ) : (
              files.map((file) => (
                <motion.div 
                  key={file.id}
                  className="bg-background/30 rounded-lg p-4 border border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300 hover:translate-y-[-5px] hover:shadow-lg hover:shadow-cyan-500/30"
                  whileHover={{ y: -5 }}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="bg-cyan-500/20 p-2 rounded">
                      <span className="text-2xl text-cyan-500">{
                        (() => {
                          const icon = getFileIcon(file.type);
                          return icon === 'file-pdf' ? '📄' :
                                 icon === 'key' ? '🔑' :
                                 icon === 'image' ? '🖼️' :
                                 icon === 'file-text' ? '📝' :
                                 icon === 'file-spreadsheet' ? '📊' : '📄';
                        })()
                      }</span>
                    </div>
                    <div className="flex space-x-2">
                      <button className="text-neutral/60 hover:text-cyan-500">
                        {file.type === 'key' ? '👁️' : '⬇️'}
                      </button>
                      <button 
                        className="text-neutral/60 hover:text-red-500"
                        onClick={() => deleteFile(file.id)}
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  <h4 className="font-mono text-cyan-500 mb-1">{file.name}</h4>
                  <p className="text-xs text-neutral/60 mb-3">
                    Added: {formatDate(new Date(file.createdAt))}
                  </p>
                  <div className="flex items-center text-xs text-neutral/60">
                    <span className="mr-1 text-cyan-500/80">🔒</span>
                    <span>AES-256 Encrypted</span>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </motion.div>
      )}
      
      {/* Notes Section */}
      {activeSection === 'notes' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-primary/50 rounded-lg border border-cyan-500/30 p-6"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-mono text-lg">Secured Notes</h3>
            <Dialog open={isAddNoteOpen} onOpenChange={setIsAddNoteOpen}>
              <DialogTrigger asChild>
                <Button className="bg-cyan-500 hover:bg-cyan-500/80 text-background font-mono py-2 px-4 rounded flex items-center text-sm">
                  <span className="mr-2">+</span>
                  ADD NEW
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Note</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="noteTitle" className="text-sm">Title</label>
                    <Input 
                      id="noteTitle"
                      value={newNote.title}
                      onChange={(e) => setNewNote({...newNote, title: e.target.value})}
                      placeholder="Enter note title"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="noteContent" className="text-sm">Content</label>
                    <Textarea 
                      id="noteContent"
                      value={newNote.content}
                      onChange={(e) => setNewNote({...newNote, content: e.target.value})}
                      placeholder="Enter note content"
                      rows={6}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    onClick={handleAddNote}
                    className="bg-cyan-500 hover:bg-cyan-500/80"
                  >
                    Add Note
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {/* Notes Grid */}
          <div className="grid grid-cols-1 gap-4">
            {notes.length === 0 && !isLoading ? (
              <p className="text-center text-gray-400 py-8">No notes added yet.</p>
            ) : (
              notes.map((note) => (
                <Card key={note.id} className="bg-background/30 border-cyan-500/10 hover:border-cyan-500/30">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <h4 className="font-mono text-cyan-500">{note.title}</h4>
                      <div className="flex space-x-2">
                        <button 
                          className="text-neutral/60 hover:text-red-500"
                          onClick={() => deleteNote(note.id)}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                    <p className="text-sm mb-3 whitespace-pre-wrap">{note.content}</p>
                    <p className="text-xs text-neutral/60">
                      Added: {formatDate(new Date(note.createdAt))}
                    </p>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </motion.div>
      )}
      
      {/* Settings Section */}
      {activeSection === 'settings' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-primary/50 rounded-lg border border-cyan-500/30 p-6"
        >
          <h3 className="font-mono text-lg mb-6">Security Settings</h3>
          
          <div className="space-y-6">
            <div className="p-4 border border-cyan-500/20 rounded-lg">
              <h4 className="font-mono text-cyan-500 mb-2">Voice Authentication</h4>
              <p className="text-sm mb-4">Your voice pattern is used as a biometric security key.</p>
              <Button variant="outline" className="border-cyan-500/30 text-cyan-500">
                Update Voice Pattern
              </Button>
            </div>
            
            <div className="p-4 border border-cyan-500/20 rounded-lg">
              <h4 className="font-mono text-cyan-500 mb-2">Passcode</h4>
              <p className="text-sm mb-4">Change your backup passcode for emergencies.</p>
              <Button variant="outline" className="border-cyan-500/30 text-cyan-500">
                Change Passcode
              </Button>
            </div>
            
            <div className="p-4 border border-red-500/20 rounded-lg">
              <h4 className="font-mono text-red-500 mb-2">Danger Zone</h4>
              <p className="text-sm mb-4">These actions cannot be undone.</p>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 border border-red-500/20 rounded">
                  <div>
                    <h5 className="text-sm font-semibold">Self-Destruct All Data</h5>
                    <p className="text-xs text-neutral/60">Permanently delete all files and notes.</p>
                  </div>
                  <Button variant="destructive" className="bg-red-500 hover:bg-red-600">
                    Destroy
                  </Button>
                </div>
                
                <div className="flex justify-between items-center p-3 border border-red-500/20 rounded">
                  <div>
                    <h5 className="text-sm font-semibold">Delete Account</h5>
                    <p className="text-xs text-neutral/60">Permanently delete your account and all associated data.</p>
                  </div>
                  <Button variant="destructive" className="bg-red-500 hover:bg-red-600">
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Footer */}
      <div className="mt-16 text-center opacity-60 text-sm font-mono">
        <p>VOICE VAULT v1.0</p>
        <p className="text-xs mt-1">SECURE SELF-DESTRUCTING STORAGE</p>
      </div>
    </div>
  );
};

export default VaultScreen;
