import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/context/AuthContext';
import { useVoiceRecognition } from '@/hooks/useVoiceRecognition';
import { useToast } from '@/hooks/use-toast';
import MouseCharacter from './MouseCharacter';
import VoiceWave from './VoiceWave';
import { Button } from '@/components/ui/button';

interface AuthenticationScreenProps {
  onSuccess: () => void;
}

const AuthenticationScreen: React.FC<AuthenticationScreenProps> = ({ onSuccess }) => {
  const [username, setUsername] = useState("mayank");
  const [voiceSupported, setVoiceSupported] = useState(true);
  const { toast } = useToast();

  const { 
    isListening, 
    isProcessing, 
    isFailed, 
    isSuccess, 
    failedAttempts,
    startVoiceAuth,
    authenticateVoice
  } = useAuth();

  // Check for voice recognition support
  useEffect(() => {
    // @ts-ignore - SpeechRecognition might not be recognized by TypeScript but will work at runtime
    const hasVoiceSupport = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    setVoiceSupported(hasVoiceSupport);
    
    if (!hasVoiceSupport) {
      toast({
        title: "Voice Recognition Not Supported",
        description: "Please use the demo buttons below to test the application.",
        variant: "destructive",
      });
    }
  }, [toast]);
  
  // Set up voice recognition
  useVoiceRecognition({
    onResult: (text, audioData) => {
      try {
        // For demo, we're just checking if the text contains "1234"
        // In a real app, you would use the audioData for voice pattern matching
        authenticateVoice(username, text).then(success => {
          if (success) {
            onSuccess();
          }
        }).catch(err => {
          console.error("Authentication error:", err);
        });
      } catch (error) {
        console.error("Voice recognition result error:", error);
      }
    },
    onError: (error) => {
      console.error("Speech recognition error", error);
      // Automatically try the success demo if voice recognition fails
      if (error === "no-speech" || error === "network") {
        toast({
          title: "Voice Recognition Error",
          description: "Using demo mode instead. In a real environment, voice recognition would work.",
        });
      }
    },
    isActive: isListening
  });
  
  const handleStartAuth = () => {
    if (!voiceSupported) {
      toast({
        title: "Voice Recognition Not Supported",
        description: "Please use the demo buttons below to test the application.",
      });
      return;
    }
    startVoiceAuth();
  };
  
  // For demo purposes
  const handleSuccessDemo = () => {
    try {
      authenticateVoice(username, "1234").then(success => {
        if (success) {
          onSuccess();
        }
      }).catch(err => {
        console.error("Success demo error:", err);
        toast({
          title: "Authentication Error",
          description: "There was an error with the demo. Please try again.",
          variant: "destructive",
        });
      });
    } catch (error) {
      console.error("Success demo error:", error);
    }
  };
  
  const handleFailDemo = () => {
    try {
      authenticateVoice(username, "wrong").catch((err) => {
        console.error("Fail demo error:", err);
      });
    } catch (error) {
      console.error("Fail demo error:", error);
    }
  };
  
  const getStatusText = () => {
    if (isListening) return "VOICE INPUT ACTIVE";
    if (isProcessing) return "PROCESSING";
    if (isSuccess) return "ACCESS GRANTED";
    if (isFailed) return `ATTEMPT ${failedAttempts}/5 FAILED`;
    return "WAITING FOR AUTHENTICATION";
  };
  
  const getStatusClass = () => {
    if (isListening) return "text-amber-400";
    if (isProcessing) return "text-amber-400";
    if (isSuccess) return "text-emerald-400";
    if (isFailed) return "text-red-400";
    return "";
  };
  
  const getPromptText = () => {
    if (!voiceSupported) return "Voice recognition not supported in this environment. Use demo buttons below.";
    if (isListening) return "Listening for passphrase...";
    if (isProcessing) return "Analyzing voice pattern...";
    if (isSuccess) return "Voice pattern recognized. Welcome, Mayank!";
    if (isFailed) return "Voice pattern mismatch. Try again.";
    return "Hi Mayank, tell me the secret code.";
  };
  
  return (
    <div className="w-full max-w-md">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="font-['Audiowide'] text-4xl mb-2 text-cyan-500">VOICE VAULT</h1>
        <p className="font-mono text-sm text-neutral/80">SECURE SELF-DESTRUCTING STORAGE</p>
      </div>
      
      {/* Security Status Indicator */}
      <div className="flex justify-center mb-6">
        <div className="bg-primary/50 px-4 py-2 rounded-full border border-cyan-500/30 flex items-center">
          <span className="inline-block w-3 h-3 rounded-full bg-cyan-500 animate-pulse mr-2"></span>
          <span className={`font-mono text-sm tracking-widest ${getStatusClass()}`}>
            {getStatusText()}
          </span>
        </div>
      </div>
      
      {/* Mouse Character */}
      <MouseCharacter 
        isTalking={isListening} 
        isProcessing={isProcessing} 
      />
      
      {/* Speech Bubble */}
      <div className="relative bg-primary p-5 rounded-lg border border-cyan-500/30 mb-6 max-w-sm mx-auto">
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-5 h-5 bg-primary border-t border-l border-cyan-500/30 rotate-45"></div>
        <p className="text-center font-mono">{getPromptText()}</p>
        
        {/* Voice Recognition Animation */}
        <VoiceWave isActive={isListening} />
        
        {/* Processing Animation */}
        {isProcessing && (
          <div className="text-center py-2">
            <span className="font-mono text-sm">Processing</span>
            <motion.span 
              className="inline-flex"
              animate={{ opacity: [0.2, 1, 0.2] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <span className="mx-0.5">.</span>
              <span className="mx-0.5" style={{ animationDelay: "0.2s" }}>.</span>
              <span className="mx-0.5" style={{ animationDelay: "0.4s" }}>.</span>
            </motion.span>
          </div>
        )}
      </div>
      
      {/* Authentication Controls */}
      <div className="flex flex-col items-center">
        {/* Attempt Counter */}
        <div className="flex space-x-2 mb-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div 
              key={i}
              className={`w-3 h-3 rounded-full ${
                i < failedAttempts 
                  ? "bg-red-500" 
                  : i === failedAttempts 
                    ? "bg-amber-500" 
                    : "bg-primary border border-gray-600"
              }`}
            ></div>
          ))}
        </div>
        
        {/* Voice Authentication Button */}
        <Button
          onClick={handleStartAuth}
          disabled={isListening || isProcessing}
          className={`bg-cyan-500 hover:bg-cyan-500/80 text-background font-mono py-3 px-8 rounded-lg flex items-center transition-all shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/30 ${
            (isListening || isProcessing) ? "opacity-50" : ""
          }`}
        >
          <i className="mr-2">🎤</i>
          START VOICE AUTHENTICATION
        </Button>
        
        {/* Debug Buttons (Would be removed in production) */}
        <div className="mt-4 flex space-x-4">
          <button 
            onClick={handleSuccessDemo} 
            className="text-xs text-gray-500 hover:text-cyan-500"
          >
            Success Demo
          </button>
          <button 
            onClick={handleFailDemo} 
            className="text-xs text-gray-500 hover:text-red-500"
          >
            Fail Demo
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthenticationScreen;
