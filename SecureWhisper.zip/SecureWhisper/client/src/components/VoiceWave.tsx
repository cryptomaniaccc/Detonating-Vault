import React from 'react';
import { motion } from 'framer-motion';

interface VoiceWaveProps {
  isActive: boolean;
}

const VoiceWave: React.FC<VoiceWaveProps> = ({ isActive }) => {
  return (
    <div className={`flex items-center justify-center h-12 ${isActive ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
      {Array.from({ length: 7 }).map((_, i) => (
        <motion.span
          key={i}
          className="w-1 mx-0.5 rounded-full bg-cyan-500"
          animate={{
            height: isActive ? ["5px", "30px", "5px"] : "5px"
          }}
          transition={{
            duration: 1.2,
            ease: "easeInOut",
            repeat: Infinity,
            delay: i * 0.1
          }}
        />
      ))}
    </div>
  );
};

export default VoiceWave;
