import React from 'react';
import { motion } from 'framer-motion';

interface MouseCharacterProps {
  isTalking: boolean;
  isProcessing: boolean;
}

const MouseCharacter: React.FC<MouseCharacterProps> = ({ isTalking, isProcessing }) => {
  return (
    <div className="relative w-64 h-64 mx-auto mb-8">
      <div className="relative w-60 h-60 bg-primary rounded-full mx-auto shadow-lg border-2 border-cyan-500/20 flex items-center justify-center overflow-hidden">
        {/* Mouse Ears */}
        <div className="absolute top-[-30px] left-[15px] w-[60px] h-[60px] rounded-full bg-gray-700" />
        <div className="absolute top-[-30px] right-[15px] w-[60px] h-[60px] rounded-full bg-gray-700" />
        
        {/* Mouse Face */}
        <div className="relative w-40 h-40">
          {/* Eyes */}
          <div className="absolute top-10 left-4 w-10 h-10 rounded-full bg-background border-2 border-cyan-500/50 flex items-center justify-center">
            <motion.div 
              className="w-4 h-4 rounded-full bg-cyan-500"
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ 
                repeat: Infinity, 
                duration: 3, 
                ease: "easeInOut" 
              }}
            />
          </div>
          <div className="absolute top-10 right-4 w-10 h-10 rounded-full bg-background border-2 border-cyan-500/50 flex items-center justify-center">
            <motion.div 
              className="w-4 h-4 rounded-full bg-cyan-500"
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ 
                repeat: Infinity, 
                duration: 3, 
                ease: "easeInOut",
                delay: 0.1
              }}
            />
          </div>
          
          {/* Nose */}
          <div className="absolute top-24 left-1/2 transform -translate-x-1/2 w-6 h-4 bg-gray-700 rounded-full" />
          
          {/* Mouth */}
          <motion.div 
            className="absolute top-32 left-1/2 transform -translate-x-1/2 w-16 bg-gray-800 rounded-lg overflow-hidden"
            animate={{ 
              height: isTalking ? ["5px", "10px", "5px"] : "5px"
            }}
            transition={{ 
              repeat: isTalking ? Infinity : 0, 
              duration: 0.5, 
              ease: "easeInOut" 
            }}
          >
            <div className="h-full w-full bg-background/20" />
          </motion.div>
          
          {/* Whiskers */}
          <div className="absolute top-[75px] left-[15px] w-[25px] h-[1px] bg-gray-400 transform -rotate-15" />
          <div className="absolute top-[80px] left-[10px] w-[25px] h-[1px] bg-gray-400 transform -rotate-5" />
          <div className="absolute top-[75px] right-[15px] w-[25px] h-[1px] bg-gray-400 transform rotate-15" />
          <div className="absolute top-[80px] right-[10px] w-[25px] h-[1px] bg-gray-400 transform rotate-5" />
        </div>
        
        {/* Mouse Tail */}
        <div className="absolute bottom-[-20px] right-[-20px] w-[50px] h-[50px] border-2 border-transparent border-l-gray-600 rounded-full transform rotate-45" />
        
        {/* Scanline effect for tech feel */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/20 to-transparent bg-[size:100%_8px] pointer-events-none opacity-10" />
      </div>
      
      {/* Processing indicator (circular animation around mouse) */}
      {isProcessing && (
        <motion.div 
          className="absolute inset-0 rounded-full border-2 border-cyan-500/50"
          animate={{ scale: [1, 1.1, 1], opacity: [0.2, 0.5, 0.2] }}
          transition={{ 
            repeat: Infinity, 
            duration: 2, 
            ease: "easeInOut" 
          }}
        />
      )}
    </div>
  );
};

export default MouseCharacter;
