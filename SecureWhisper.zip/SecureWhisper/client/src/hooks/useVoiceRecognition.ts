import { useState, useEffect, useCallback, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { audioToString } from '@/lib/utils';

// Add TypeScript definitions for the Web Speech API
interface SpeechRecognitionEvent extends Event {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: (event: Event) => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: { error: string }) => void;
  onend: () => void;
}

declare global {
  interface Window {
    SpeechRecognition: {
      new(): SpeechRecognition;
    };
    webkitSpeechRecognition: {
      new(): SpeechRecognition;
    };
  }
}

interface UseVoiceRecognitionProps {
  onResult?: (text: string, audioData: string) => void;
  onStart?: () => void;
  onStop?: () => void;
  onError?: (error: string) => void;
  isActive: boolean;
}

export function useVoiceRecognition({ 
  onResult, 
  onStart, 
  onStop, 
  onError,
  isActive 
}: UseVoiceRecognitionProps) {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioDataRef = useRef<Float32Array | null>(null);
  const analyzerRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();

  // Setup and start voice recognition
  const startListening = useCallback(async () => {
    if (!navigator.mediaDevices || !window.SpeechRecognition && !window.webkitSpeechRecognition) {
      toast({
        title: "Error",
        description: "Voice recognition not supported by this browser",
        variant: "destructive",
      });
      if (onError) onError("Voice recognition not supported");
      return;
    }
    
    try {
      // Setup audio capture
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const source = audioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
      analyzerRef.current = audioContextRef.current.createAnalyser();
      analyzerRef.current.fftSize = 2048;
      
      const bufferLength = analyzerRef.current.frequencyBinCount;
      audioDataRef.current = new Float32Array(bufferLength);
      
      source.connect(analyzerRef.current);
      
      // Setup speech recognition
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'en-US';
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onstart = () => {
        setIsListening(true);
        if (onStart) onStart();
      };
      
      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        
        // Capture audio data
        if (analyzerRef.current && audioDataRef.current) {
          analyzerRef.current.getFloatTimeDomainData(audioDataRef.current);
          const audioDataString = audioToString(audioDataRef.current);
          
          if (onResult) onResult(transcript, audioDataString);
        }
      };
      
      recognitionRef.current.onerror = (event: { error: string }) => {
        console.error('Speech recognition error', event.error);
        if (onError) onError(event.error);
      };
      
      recognitionRef.current.onend = () => {
        stopListening();
      };
      
      recognitionRef.current.start();
    } catch (error) {
      console.error('Error starting voice recognition:', error);
      if (onError) onError(String(error));
      toast({
        title: "Error",
        description: "Could not access microphone",
        variant: "destructive",
      });
    }
  }, [onStart, onResult, onError, toast]);

  // Stop voice recognition
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (error) {
        console.error('Error stopping recognition:', error);
      }
    }
    
    if (mediaStreamRef.current) {
      try {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      } catch (error) {
        console.error('Error stopping media tracks:', error);
      }
    }
    
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (error) {
        console.error('Error closing audio context:', error);
      }
    }
    
    setIsListening(false);
    if (onStop) onStop();
  }, [onStop]);

  // Control listening based on isActive prop
  useEffect(() => {
    if (isActive && !isListening) {
      startListening();
    } else if (!isActive && isListening) {
      stopListening();
    }
    
    return () => {
      if (isListening) {
        stopListening();
      }
    };
  }, [isActive, isListening, startListening, stopListening]);

  return { isListening };
}
